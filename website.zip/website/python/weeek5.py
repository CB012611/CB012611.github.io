input_list = [10, 2, 7, 5, 38, 3]
max_num = max(input_list)
min_num = min(input_list)
print("Maximum:", max_num)
print("Minimum:", min_num)

input_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
output_list = input_list[2:6]
print(output_list)